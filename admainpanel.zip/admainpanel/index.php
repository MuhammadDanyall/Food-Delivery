<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <link rel="stylesheet" href="style.css">
    <style>body {
    font-family: Arial, sans-serif;
    background-color: #f0f0f0; /* Lighter background for better readability */
    margin: 0; /* Remove default margin */
    padding: 0;
}

#wrapper {
    max-width: 1000px; /* Set max-width for responsiveness */
    margin: 0 auto;
    background-color: #fff;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    padding: 20px;
    margin-bottom: 15px;
}

/* Header Styling */
#header {
    text-align: center;
    background-color: #1abc9c;
    color: #fff;
    padding: 20px;
    margin-bottom: 20px;
    box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.2);
}

#header h1 {
    font-size: 32px; /* Increased font size for better visibility */
    font-weight: bold;
    text-transform: uppercase;
    margin: 0;
}
#menu{
    background-color: #333;
}
#menu ul{
    font-size: 0;
    padding: 0 10px;
    margin: 0;
    list-style: none;
}
#menu ul li{
    display: inline-block;
}
#menu ul li a{
    color: #fff;
    font-size: 16px;
    font-weight: 600;
    padding: 8px 10px;
    display: block;
    text-decoration: none;
    text-transform: uppercase;
    transition: all 0.3s ease;
}

#menu ul li a:hover{
    background-color: rgba(255,255,255,0.2);
}

/* CRUD Heading Styling */
#crud-heading {
    text-align: center;
    background-color: #1abc9c;
    color: #fff;
    padding: 15px;
    margin-bottom: 20px;
    box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.2);
}

#crud-heading h2 {
    font-size: 24px;
    font-weight: bold;
    text-transform: uppercase;
    margin: 0;
}

/* Table Styling */
#main-content table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 20px;
    box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
}

#main-content table th,
#main-content table td {
    border: 1px solid #ddd; /* Lighter border color */
    padding: 15px;
    text-align: center;
}

#main-content table th {
    background-color: #f2f2f2; /* Lighter header background */
    color: #333;
    font-weight: bold;
    text-transform: uppercase;
}

#main-content table td {
    background-color: #fff;
    color: #333;
}

#main-content table tr:nth-child(even) {
    background-color: #f9f9f9; /* Subtle alternating row color */
}

/* Button Styling */
#main-content table td a {
    font-size: 14px;
    font-weight: bold;
    color: #fff;
    padding: 8px 16px;
    text-decoration: none;
    border-radius: 5px;
    margin: 5px;
    display: inline-block;
    transition: background-color 0.3s ease;
}

#main-content table td a:first-child {
    background-color: #4CAF50; /* Green for Edit */
}

#main-content table td a:first-child:hover {
    background-color: #3e8e41;
}

#main-content table td a:last-child {
    background-color: #f44336; /* Red for Delete */
}

#main-content table td a:last-child:hover {
    background-color: #944949;
}</style>
    
</head>
<body>
    <div id="wrapper">
        <div id="header">
            <h1>Food Finder Admin Panel</h1>
        </div>
        <div id="main-content">
            <table>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Location</th>
                    <th>Phone</th>
                    <th>Order</th>
                    <th>Actions</th>
                </tr>
                <?php 
                include 'header.php';
                $con = mysqli_connect('localhost','root','','fooddelivery') or die('Connection failed');
                $sql = 'SELECT * FROM customer_orders';
                $result = mysqli_query($con, $sql) or die('Query failed');
                
                if(mysqli_num_rows($result) > 0) {
                    while($row = mysqli_fetch_assoc($result)) { ?>
                        <tr>
                            <td><?php echo $row['id']; ?></td>
                            <td><?php echo $row['Name']; ?></td>
                            <td><?php echo $row['Location']; ?></td>
                            <td><?php echo $row['Phone']; ?></td>
                            <td><?php echo $row['Order']; ?></td>
                            <td>
                                <a href="update.php?id=<?php echo $row['id']; ?>">Edit</a>
                                <a href="delete.php?id=<?php echo $row['id']; ?>">Delete</a>
                            </td>
                        </tr>
                    <?php }
                } else {
                    echo "<tr><td colspan='6'>No Records Found</td></tr>";
                }
                ?>
            </table>
        </div>
    </div>
</body>
</html>
