
<?php
include 'header.php';
$con = mysqli_connect('localhost', 'root', '', 'fooddelivery') or die('Connection failed');

// Check if the ID is set
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Fetch existing data
    $sql = "SELECT * FROM customer_orders WHERE id = {$id}";
    $result = mysqli_query($con, $sql);
    
    if ($result && mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
    } else {
        echo "Record not found.";
        exit();
    }
}

// Update record after form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['Name'];
    $location = $_POST['Location'];
    $phone = $_POST['Phone'];
    $order = $_POST['Order'];

    // Update query
    $sql = "UPDATE customer_orders SET Name = '{$name}', Location = '{$location}', Phone = '{$phone}', `Order` = '{$order}' WHERE id = {$id}";

    if (mysqli_query($con, $sql)) {
        // Redirect to the main page after updating
        header("Location: index.php");
        exit();
    } else {
        echo "Error updating record: " . mysqli_error($con);
    }
}

mysqli_close($con);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
    <style>body{
    font:16px arial;
    margin: 0;
    padding: 0;
    background: #d1d1d1;
}

#wrapper{
    width: 1000px;
    margin: 50px auto 0;
    background-color: #fff;
}

#header{
    text-align: center;
    background-color: #1abc9c;
    padding: 10px;
}

#header h1{
    color: #fff;
    font-size: 40px;
    font-style: italic;
    font-weight: 700;
    text-transform: uppercase;
    margin: 0;
}

#menu{
    background-color: #333;
}
#menu ul{
    font-size: 0;
    padding: 0 10px;
    margin: 0;
    list-style: none;
}
#menu ul li{
    display: inline-block;
}
#menu ul li a{
    color: #fff;
    font-size: 16px;
    font-weight: 600;
    padding: 8px 10px;
    display: block;
    text-decoration: none;
    text-transform: uppercase;
    transition: all 0.3s ease;
}

#menu ul li a:hover{
    background-color: rgba(255,255,255,0.2);
}

#main-content{
     padding: 25px;
    min-height: 400px;
}
#main-content h2{
    margin: 0 0 10px;
    text-transform: capitalize;
}

#main-content table{
    width: 100%;
    background-color: #555;
    margin: 0 0 20px;
}

#main-content table th{
    color: #fff;
    background-color: #333;
    text-transform: uppercase;
}
#main-content table th:last-child{
    width: 130px;
}
#main-content table td{
    background-color: #fff;
}
#main-content table td a{
    font-size: 14px;
    font-weight: 600;
    text-transform: uppercase;
    padding: 3px 7px;
    color: #fff;
    background-color: #e67e22;
    text-decoration: none;
    border-radius: 3px;
}
#main-content table td a:nth-child(2){
    background-color: #e74c3c;
    margin: 0 0 0 5px;
}

#main-content .post-form{
    width: 50%;
    padding: 25px;
    margin: 0 auto;
    background-color: #f5f5f5;
    border-radius: 10px;
}

#main-content .post-form .form-group{
    margin: 0 0 15px;
}

#main-content .post-form .form-group label{
    width: 30%;
    display: inline-block;
    font-weight: 600;
}
#main-content .post-form .form-group input,
#main-content .post-form .form-group select{
    font-size: 16px;
    width: 66%;
    display: inline-block;
    padding: 5px;
    margin: 0;
}
#main-content .post-form .form-group select{
    width: 69%;
}

#main-content .post-form .submit{
    font-size: 17px;
    letter-spacing: 1px;
    text-transform: uppercase;
    padding: 5px 10px;
    color: #fff;
    background-color: #333;
    border: none;
    border-radius: 5px;
    margin: 0 0 0 30%;
    cursor: pointer;
    transition: all 0.3s;
}

#main-content .post-form .submit:hover{
    box-shadow: 0 0 5px #555;
}

#main-content .pagination{
    padding: 0;
    margin: 0;
    list-style: none;
}

#main-content .pagination li{
    display: inline-block;
}

#main-content .pagination li a{
    height: 30px;
    width: 30px;
    line-height: 30px;
    font-size: 18px;
    text-align: center;
    text-decoration: none;
    color: #fff;
    background-color: #1abc9c;
    display: block;
    margin: 0 5px 0 0;
    transition: all 0.3s;
}

#main-content .pagination li a:hover{
    background-color: #333;
}</style>
</head>
<body>
<?php include 'header.php'; ?>
<div id="main-content">


    <h2>Edit Record</h2>
    <form action="" method="post">
        <label for="Name">Name:</label>
        <input type="text" name="Name" id="Name" value="<?php echo $row['Name']; ?>" required><br><br>

        <label for="Location">Location:</label>
        <input type="text" name="Location" id="Location" value="<?php echo $row['Location']; ?>" required><br><br>

        <label for="Phone">Phone:</label>
        <input type="text" name="Phone" id="Phone" value="<?php echo $row['Phone']; ?>" required><br><br>

        <label for="Order">Order:</label>
        <input type="text" name="Order" id="Order" value="<?php echo $row['Order']; ?>" required><br><br>

        <input type="submit" value="Update">
    </form>
</div>
</div>

</body>
</html>