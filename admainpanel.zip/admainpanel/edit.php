<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    
<?php include 'header.php'; ?>

<div id="main-content">
    <h2>Update Record</h2>
    <form class="post-form" action="index.php.php" method="post">
      <div class="form-group">
          <label>Name</label>
          <input type="hidden" name="sid" value=""/>
          <input type="text" name="sname" value=""/>
      </div>
      <div class="form-group">
          <label>Location</label>
          <input type="text" name="Location" value=""/>
      </div>
      <div class="form-group">
          <label>Phone</label>
        <input type="text" name="Phone " value = ""/>
      </div>
      <div class="form-group">
          <label>Order</label>
          <input type="text" name="Order" value=""/>
      </div>
      <input class="submit" type="submit" value="Update"/>
    </form>
</div>
</div>

</body>
</html>