
<?php
// Connect to the database
include 'header.php';
$con = mysqli_connect('localhost', 'root', '', 'fooddelivery') or die('Connection failed');

// Check if `id` parameter is set in the URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Delete query
    $sql = "DELETE FROM customer_orders WHERE id = {$id}";

    if (mysqli_query($con, $sql)) {
        // Redirect to the main page after deletion
        header("Location: index.php");
        exit();
    } else {
        echo "Error deleting record: " . mysqli_error($con);
    }
} else {
    echo "Invalid ID.";
}

// Close the connection
mysqli_close($con);
?>





<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>

    <style>body {
    font-family: Arial, sans-serif;
    background-color: #f0f0f0; /* Lighter background for better readability */
    margin: 0; /* Remove default margin */
    padding: 0;
}

#wrapper {
    max-width: 1000px; /* Set max-width for responsiveness */
    margin: 0 auto;
    background-color: #fff;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    padding: 20px;
    margin-bottom: 15px;
}

/* Header Styling */
#header {
    text-align: center;
    background-color: #1abc9c;
    color: #fff;
    padding: 20px;
    margin-bottom: 20px;
    box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.2);
}

#header h1 {
    font-size: 32px; /* Increased font size for better visibility */
    font-weight: bold;
    text-transform: uppercase;
    margin: 0;
}
#menu{
    background-color: #333;
}
#menu ul{
    font-size: 0;
    padding: 0 10px;
    margin: 0;
    list-style: none;
}
#menu ul li{
    display: inline-block;
}
#menu ul li a{
    color: #fff;
    font-size: 16px;
    font-weight: 600;
    padding: 8px 10px;
    display: block;
    text-decoration: none;
    text-transform: uppercase;
    transition: all 0.3s ease;
}

#menu ul li a:hover{
    background-color: rgba(255,255,255,0.2);
}

/* CRUD Heading Styling */
#crud-heading {
    text-align: center;
    background-color: #1abc9c;
    color: #fff;
    padding: 15px;
    margin-bottom: 20px;
    box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.2);
}

#crud-heading h2 {
    font-size: 24px;
    font-weight: bold;
    text-transform: uppercase;
    margin: 0;
}

/* Table Styling */

#main-content{
     padding: 25px;
    min-height: 400px;
}
#main-content h2{
    margin: 0 0 10px;
    text-transform: capitalize;
}

#main-content table{
    width: 100%;
    background-color: #555;
    margin: 0 0 20px;
}

#main-content table th{
    color: #fff;
    background-color: #333;
    text-transform: uppercase;
}
#main-content table th:last-child{
    width: 130px;
}
#main-content table td{
    background-color: #fff;
}
#main-content table td a{
    font-size: 14px;
    font-weight: 600;
    text-transform: uppercase;
    padding: 3px 7px;
    color: #fff;
    background-color: #e67e22;
    text-decoration: none;
    border-radius: 3px;
}
#main-content table td a:nth-child(2){
    background-color: #e74c3c;
    margin: 0 0 0 5px;
}

#main-content .post-form{
    width: 50%;
    padding: 25px;
    margin: 0 auto;
    background-color: #f5f5f5;
    border-radius: 10px;
}

#main-content .post-form .form-group{
    margin: 0 0 15px;
}

#main-content .post-form .form-group label{
    width: 30%;
    display: inline-block;
    font-weight: 600;
}
#main-content .post-form .form-group input,
#main-content .post-form .form-group select{
    font-size: 16px;
    width: 66%;
    display: inline-block;
    padding: 5px;
    margin: 0;
}
#main-content .post-form .form-group select{
    width: 69%;
}

#main-content .post-form .submit{
    font-size: 17px;
    letter-spacing: 1px;
    text-transform: uppercase;
    padding: 5px 10px;
    color: #fff;
    background-color: #333;
    border: none;
    border-radius: 5px;
    margin: 0 0 0 30%;
    cursor: pointer;
    transition: all 0.3s;
}

#main-content .post-form .submit:hover{
    box-shadow: 0 0 5px #555;
}

#main-content .pagination{
    padding: 0;
    margin: 0;
    list-style: none;
}

#main-content .pagination li{
    display: inline-block;
}

#main-content .pagination li a{
    height: 30px;
    width: 30px;
    line-height: 30px;
    font-size: 18px;
    text-align: center;
    text-decoration: none;
    color: #fff;
    background-color: #1abc9c;
    display: block;
    margin: 0 5px 0 0;
    transition: all 0.3s;
}

#main-content .pagination li a:hover{
    background-color: #333;
}</style>

</head>
<body>


<div id="main-content">
    <h2>Delete Record</h2>
    <form class="post-form" action="index.php" method="post">
        <div class="form-group">
            <label>id</label>
            <input type="text" name="sid" />
        </div>
        <input class="submit" type="submit" name="deletebtn" value="Delete" />
    </form>
</div>
</div>

    
</body>
</html>