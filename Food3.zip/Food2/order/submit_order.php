<?php

$name = $_POST['name'];
$location = $_POST['location'];
$phone = $_POST['phone'];
$order = $_POST['order'];

$conn = mysqli_connect('localhost', 'root', '', 'fooddelivery') or die('connection fail');
$sql = "INSERT INTO customer_orders (Name, Location, Phone, `Order`) VALUES ('$name', '$location', '$phone', '$order')";
mysqli_query($conn, $sql) or die('query fail');

header('Location: http://localhost/food/food.html');
mysqli_close($conn);

?>





